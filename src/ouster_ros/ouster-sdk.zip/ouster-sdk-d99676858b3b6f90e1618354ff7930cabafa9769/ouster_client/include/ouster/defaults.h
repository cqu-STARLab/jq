#pragma once

constexpr int DEFAULT_HTTP_REQUEST_TIMEOUT_SECONDS = 40;
constexpr int DEFAULT_COLUMNS_PER_PACKET = 16;
