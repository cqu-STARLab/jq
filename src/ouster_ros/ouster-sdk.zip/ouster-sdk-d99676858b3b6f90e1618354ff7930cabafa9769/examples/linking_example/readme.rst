============================
Simple ouster_pcap Example
============================

This is a simple example on how to build and link a cpp project with the ouster_pcap
library.

.. code-block:: bash
    ./example.bash
   
