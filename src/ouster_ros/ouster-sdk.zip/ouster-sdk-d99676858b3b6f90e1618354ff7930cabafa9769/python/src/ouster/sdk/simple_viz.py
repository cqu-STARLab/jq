"""
Copyright (c) 2022, Ouster, Inc.
All rights reserved.
"""

# TODO: remove


def main() -> None:
    print("We have moved simple-viz into our new command line utility. "
          "To use it, type: "
          "\n\touster-cli source [SENSOR HOSTNAME OR PCAP] viz")
