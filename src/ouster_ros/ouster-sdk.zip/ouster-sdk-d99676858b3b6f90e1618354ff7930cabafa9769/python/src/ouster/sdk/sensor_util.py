# TODO: remove
raise RuntimeError("The methods in this file have been move to ouster.sensor.util."
" THIS FILE WILL BE REMOVED IN NEXT RELEASE")
