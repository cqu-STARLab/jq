raise RuntimeError("The ouster.osf.multi has been renamed to ouster.osf.osf_scan_source under"
"the ouster.osf package. THIS FILE WILL BE REMOVED IN NEXT RELEASE")
