# flake8: noqa (unused imports)

print("warning: the ouster.viz module has been moved to ouster.sdk.viz, "
      "please use the new path to avoid this warning.")
from ouster.sdk.viz import *
