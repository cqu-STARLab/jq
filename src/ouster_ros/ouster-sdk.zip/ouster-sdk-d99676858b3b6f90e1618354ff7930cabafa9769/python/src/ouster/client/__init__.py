# flake8: noqa (unused imports)

print("warning: the ouster.client module has been moved to ouster.sdk.client, "
      "please use the new path to avoid this warning.")
from ouster.sdk.client import *
