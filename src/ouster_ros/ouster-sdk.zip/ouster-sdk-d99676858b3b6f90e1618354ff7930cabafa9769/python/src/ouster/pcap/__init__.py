# flake8: noqa (unused imports)

print("warning: the ouster.pcap module has been moved to ouster.sdk.pcap, "
      "please use the new path to avoid this warning.")
from ouster.sdk.pcap import *
