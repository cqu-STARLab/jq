# flake8: noqa (unused imports)

print("warning: the ouster.osf module has been moved to ouster.sdk.osf, "
      "please use the new path to avoid this warning.")
from ouster.sdk.osf import *