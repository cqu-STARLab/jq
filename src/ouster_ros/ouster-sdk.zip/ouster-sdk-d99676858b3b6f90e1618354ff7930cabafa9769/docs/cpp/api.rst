=====================
CPP API Documentation
=====================

.. toctree::
    :caption: C++ Api Documentation

    ouster_client <ouster_client/index.rst>
    ouster_pcap <ouster_pcap/index.rst>
    ouster_osf <ouster_osf/index.rst>

.. todo::
    Uncomment ``ouster_viz`` section below when we fix C++ PointViz doxygen comments in code

    .. ouster_viz <ouster_viz/index.rst>
