=======
crc32.h
=======

.. doxygenvariable:: ouster::osf::CRC_BYTES_SIZE

.. doxygengroup:: OsfCRCFunctions
    :content-only:
