========
writer.h
========

.. doxygenclass:: ouster::osf::ChunksWriter
    :members:

.. doxygenclass:: ouster::osf::Writer
    :members:

.. doxygenclass:: ouster::osf::ChunkBuilder
    :members:
