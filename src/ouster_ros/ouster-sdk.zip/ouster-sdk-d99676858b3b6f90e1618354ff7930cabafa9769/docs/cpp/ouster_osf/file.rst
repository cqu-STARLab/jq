======
file.h
======

.. doxygentypedef:: ouster::osf::ChunkBuffer

.. doxygenenum:: ouster::osf::OpenMode

.. doxygenenum:: ouster::osf::FileState

.. doxygenclass:: ouster::osf::OsfFile
    :members:
