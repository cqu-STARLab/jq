===================
stream_lidar_scan.h
===================

.. doxygenstruct:: ouster::osf::zero_field
    :members:

.. doxygenclass:: ouster::osf::LidarScanStreamMeta
    :members:

.. doxygengroup:: OSFTraitsLidarScanStreamMeta
    :members:
    :content-only:

.. doxygenclass:: ouster::osf::LidarScanStream
    :members:

.. doxygenfunction:: ouster::osf::slice_with_cast
