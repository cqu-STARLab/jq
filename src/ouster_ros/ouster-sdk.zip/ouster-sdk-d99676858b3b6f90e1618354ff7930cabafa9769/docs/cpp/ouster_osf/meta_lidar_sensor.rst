===================
meta_lidar_sensor.h
===================

.. doxygenclass:: ouster::osf::LidarSensor
    :members:

.. doxygengroup:: OSFTraitsLidarSensor
    :members:
    :content-only:
