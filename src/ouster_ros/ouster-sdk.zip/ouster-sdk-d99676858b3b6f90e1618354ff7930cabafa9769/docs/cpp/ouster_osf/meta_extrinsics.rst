=================
meta_extrinsics.h
=================

.. doxygenclass:: ouster::osf::Extrinsics
    :members:

.. doxygengroup:: OSFTraitsExtrinsics
    :members:
    :content-only:
