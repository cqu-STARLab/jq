==============
Ouster OSF API
==============

.. toctree::
   :caption: Ouster OSF API

   basics.h <basics.rst>
   crc32.h <crc32.rst>
   file.h <file.rst>
   layout_streaming.h <layout_streaming.rst>
   meta_extrinsics.h <meta_extrinsics.rst>
   meta_lidar_sensor.h <meta_lidar_sensor.rst>
   meta_streaming_info.h <meta_streaming_info.rst>
   metadata.h <metadata.rst>
   operations.h <operations.rst>
   pcap_source.h <pcap_source.rst>
   reader.h <reader.rst>
   stream_lidar_scan.h <stream_lidar_scan.rst>
   writer.h <writer.rst>
